export interface Todo {

    id : string;
    text : string;
    status : string;
    
}
