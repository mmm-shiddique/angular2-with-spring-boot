package com.todo.app;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import com.todo.app.model.Todo;
import com.todo.app.service.TodoServiceI;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TodoAppApplication.class)
@WebAppConfiguration
public class TodoControllerTest {

	@Autowired
	private WebApplicationContext context;

	@Autowired
	TodoServiceI todoService;
	@Mock
	Pageable page;
	@Mock
	Page<Todo> todoList;

	private static String CONTENTS;

	private MockMvc mockMvc;

	@Before
	public void setup() throws JSONException {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

		Todo todo = new Todo();
		todo.setId("1");
		todo.setStatus(1);
		todo.setText("Task Created");

		JSONObject outerObject = new JSONObject();
		JSONArray outerArray = new JSONArray();
		JSONObject innerObject = new JSONObject();
		JSONArray innerArray = new JSONArray();

		innerArray.put("test");
		innerArray.put("test1");
		innerArray.put("7676");

		innerObject.put("test2", "2");
		innerObject.put("data", innerArray);
		outerArray.put(innerObject);
		outerObject.put("rows", outerArray);

		CONTENTS = outerObject.toString();

		when(todoService.findAll(page)).thenReturn(todoList);

	}

	// Unit test positive scenario -testFindAllTodo
	@Test
	public void testFindAllTodo() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) get("/api/todo")
						.contentType(MediaType.APPLICATION_JSON_VALUE).accept(
								MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is2xxSuccessful()));
		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Correct Response Status", HttpStatus.OK.value(), status);

	}

	// Unit test negative scenario -testFindAllTodo
	@Test
	public void testFindAllTodoNotExist() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) get("/api/todo")
						.contentType(MediaType.APPLICATION_JSON_VALUE).accept(
								MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is5xxServerError()));
		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Incorrect Response Status", HttpStatus.NOT_FOUND.value(),
				status);

	}

	// Unit test positive scenario -testcreateTodo
	@Test
	public void testcreateTodo() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) post("/api/todo")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(CONTENTS)
						.accept(MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is2xxSuccessful()));
		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Correct Response Status", HttpStatus.CREATED.value(),
				status);

	}

	// Unit test negative scenario -testcreateTodo
	@Test
	public void testcreateTodoFail() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) post("/api/todo")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(CONTENTS)
						.accept(MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is5xxServerError()));
		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Incorrect Response Status",
				HttpStatus.NOT_ACCEPTABLE.value(), status);

	}

	// Unit test positive scenario -testupdateStatus
	@Test
	public void testupdateStatus() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) put(
						"/api/todo/{id}", "id")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(CONTENTS)
						.accept(MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is2xxSuccessful()));

		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Correct Response Status", HttpStatus.OK.value(), status);

	}

	// Unit test negative scenario -testupdateStatus
	@Test
	public void testupdateStatusFail() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) put(
						"/api/todo/{id}", "id")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(CONTENTS)
						.accept(MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is2xxSuccessful()));

		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Incorrect Response Status", HttpStatus.NOT_FOUND.value(),
				status);

	}

	// Unit test positive scenario -testdelete
	@Test
	public void testdelete() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) put(
						"/api/todo/{id}", "id")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(CONTENTS)
						.accept(MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is2xxSuccessful()));
		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Correct Response Status", HttpStatus.GONE.value(), status);

	}

	// Unit test negative scenario -testdelete
	@Test
	public void testdeleteFail() throws Exception {
		MvcResult result = (MvcResult) mockMvc
				.perform((RequestBuilder) ((ResultActions) put(
						"/api/todo/{id}", "id")
						.contentType(MediaType.APPLICATION_JSON_VALUE)
						.content(CONTENTS)
						.accept(MediaType.APPLICATION_JSON_VALUE))
						.andExpect(status().is2xxSuccessful()));
		// verify
		int status = result.getResponse().getStatus();
		assertEquals("Incorrect Response Status", HttpStatus.NOT_FOUND.value(),
				status);

	}

}
